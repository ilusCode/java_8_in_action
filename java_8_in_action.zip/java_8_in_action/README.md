Java8_in_action
"# java_8_in_action" 
