package main.interfaces.funcionales;

@FunctionalInterface
public interface IntPredicate {
    boolean test(int t);
}
