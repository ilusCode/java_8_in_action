package main.interfaces;

public interface Comparator<T> {
    int comapre(T o1, T o2);
}
