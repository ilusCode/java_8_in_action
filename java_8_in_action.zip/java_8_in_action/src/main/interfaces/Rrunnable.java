package main.interfaces;

public interface Rrunnable {
    void run();
}
