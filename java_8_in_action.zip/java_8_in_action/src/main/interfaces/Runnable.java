package main.interfaces;

public interface Runnable {
    void run();
}
