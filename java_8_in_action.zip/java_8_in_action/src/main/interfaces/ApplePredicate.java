package main.interfaces;

import main.model.AppleModel;

public interface ApplePredicate {
    boolean test(AppleModel apple);
}
