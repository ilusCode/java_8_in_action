package main.interfaces;

import main.model.appleModel;

public interface ApplePredicate {
    boolean test(appleModel apple);
}
