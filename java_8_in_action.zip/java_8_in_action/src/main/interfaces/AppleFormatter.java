package main.interfaces;

import main.model.AppleModel;

public interface AppleFormatter {
    String accept(AppleModel a);
}
