package main.interfaces;

import main.model.appleModel;

public interface AppleFormatter {
    String accept(appleModel a);
}
