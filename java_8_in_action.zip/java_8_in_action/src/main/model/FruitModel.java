package main.model;

public class FruitModel {
    String key;
    String nombre;
}
