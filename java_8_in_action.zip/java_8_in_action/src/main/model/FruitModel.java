package main.model;

public class FruitModel {

}
