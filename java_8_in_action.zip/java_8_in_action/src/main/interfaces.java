package main;

import java.io.Serializable;

public class interfaces implements Serializable {

    /**
     * la interface es opcional ya que existe una por defecto
     * se realizo una prueba con la interface escrita y sin que estuviera, el resultado obtenido fue el mismo
     * @param <T>
     */
    @FunctionalInterface
    public interface Predicate<T>{
        boolean test(T t);
    }
}
