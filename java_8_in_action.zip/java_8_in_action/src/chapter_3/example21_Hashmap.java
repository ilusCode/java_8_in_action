package chapter_3;

import main.interfaces.funcionales.Function;
import main.model.FruitModel;

import java.util.HashMap;
import java.util.Map;

public class example21_Hashmap {
    public static void main(String[] args) {

    }
    static Map<String, Function<Integer, FruitModel>> map=new HashMap<>();
    static {
        //map.put("banana",);
    }
}
