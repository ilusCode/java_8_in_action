package chapter_2;

import main.interfaces;
import main.model.AppleModel;

/**
 * El ejemplo actual fue extraido del libro Java 8 in action de la pagina 41 - 42
 * 2.1. Different strategies for selecting an Apple
 */
public class example5_ApplePredicate {
}
